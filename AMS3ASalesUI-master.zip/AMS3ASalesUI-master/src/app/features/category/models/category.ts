export interface Category
{
    id:string;
    description:string;
    imageURL:string;
}