export interface AddProductRequest
{
    description: string;
}