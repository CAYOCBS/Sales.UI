export interface AddCategoryRequest
{
    description:string;
}