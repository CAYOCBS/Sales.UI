export interface Product
{
    id:string;
    description:string;
    price:string;
    stock:string
    imageURL:string;
}